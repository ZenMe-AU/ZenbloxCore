import os
import sys

from a2wsgi import ASGIMiddleware
from fastapi import FastAPI
from flask import Flask, send_from_directory, url_for, render_template
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.middleware.proxy_fix import ProxyFix
from slowapi.errors import RateLimitExceeded
from slowapi import _rate_limit_exceeded_handler

from Modules.API.API import client_api_bp, APICheckerMiddleware
from Modules.API.api_extensions import api_limiter
from Modules.API.docs import configure_offline_docs
from Modules.Config import Config
from Modules.DevMode.Functions import generate_dev_certificate
from Modules.Functions import start_up_check
from Modules.Clients.Clients import client_bp
from Modules.Groups.Functions import groups_bp
from Modules.Login.Login import login_bp
from Modules.Plugins.Plugin_Manager import load_plugins
from Modules.Settings.Settings import settings_bp
from Modules.Store.store import store_bp
from Modules.Store.AutoUpdate import start_auto_updates
from Modules.UI.UI import ui_bp
from Modules.User.User import user_bp
from Modules.Winget.Functions import get_winget_Settings
from Modules.Winget.winget_Routes import winget_routes
from main_extensions import csrf, limiter
from settings import CERT_FILE, KEY_FILE


start_up_check()
settings = get_winget_Settings()
Config.init()

app = Flask(__name__)
csrf.init_app(app)
limiter.init_app(app)

app.__version__ = "2.9.2"
app.config.from_object(Config)
app.config['SERVERNAME'] = settings['SERVERNAME']
app.config['INDEXED_DB_ACTIV'] = settings.get('INDEXED_DB_ACTIV', "0")
app.config['SESSION_COOKIE_NAME'] = app.config['SERVERNAME']
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['active_downloads'] = {}
app.config['IS_DOCKER'] = '/docker' in sys.argv[1:]
app.jinja_env.add_extension('jinja2.ext.do')

app.register_blueprint(login_bp, url_prefix='/')
app.register_blueprint(ui_bp, url_prefix='/ui')
app.register_blueprint(user_bp, url_prefix='/ui/user')
app.register_blueprint(groups_bp, url_prefix='/ui/groups')
app.register_blueprint(client_bp, url_prefix='/ui/clients')
app.register_blueprint(settings_bp, url_prefix='/ui/settings')
app.register_blueprint(store_bp, url_prefix='/ui/store')
app.register_blueprint(winget_routes, url_prefix='/api')


client_api = FastAPI(title="Winget-Repo REST-API", docs_url=None, redoc_url=None)
configure_offline_docs(client_api)
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/client/api': ASGIMiddleware(client_api)
})
client_api.add_middleware(APICheckerMiddleware)
client_api.include_router(client_api_bp)
client_api.state.limiter = api_limiter
client_api.state.DOWNLOAD_KEY = app.config["DOWNLOAD_KEY"]
client_api.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


if int(settings.get('USE_PROXY', "0")) == 1:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static/images'),'favicon.png', mimetype='image/png')


@app.errorhandler(403)
def forbidden(e):
    return render_template("403.html"), 403


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


@app.errorhandler(429)
def ratelimit_handler(e):
    return render_template("429.html"), 429


@app.errorhandler(500)
def server_error(e):
    return render_template("500.html"), 500


@app.context_processor
def global_settings():
    return {
        'version_counter': app.__version__,
        'app_name': app.config['SERVERNAME'],
        'app_logo': url_for('static', filename='images/logo.png')
    }


load_plugins(app, client_api)
start_auto_updates(app)


if __name__ == '__main__':
    run_kwargs = {"threaded": True}
    ssl_env = os.environ.get('USE_SSL')
    use_ssl = False
    for arg in sys.argv[1:]:
        if arg == "/dev":
            app.config['dev_mode'] = True
            use_ssl = True
        elif arg == "/docker":
            run_kwargs["host"] = "0.0.0.0"
            if ssl_env is None:
                use_ssl = True
            else:
                use_ssl = ssl_env.lower() == "true"
        elif arg.startswith("/ssl=") and ssl_env is None:
            value = arg.split("=", 1)[1].lower()
            use_ssl = value == "true"

    if use_ssl:
        status = generate_dev_certificate()
        if not status:
            print("Error while starting the development server! Please check the certificates!")
            sys.exit(1)
        run_kwargs["ssl_context"] = (CERT_FILE, KEY_FILE)
    app.run(**run_kwargs)
