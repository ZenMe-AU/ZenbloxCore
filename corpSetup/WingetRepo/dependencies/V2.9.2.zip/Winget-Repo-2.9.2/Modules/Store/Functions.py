import os
import time
import zipfile
import yaml
import requests
import datetime
import copy

from pathlib import Path
from io import BytesIO
from uuid import uuid4
from hashlib import sha256
from werkzeug.datastructures import FileStorage

from Modules.Database.Database import SQLiteDatabase
from Modules.Database.Store_DB import StoreDB
from Modules.Functions import parse_version, get_file_edit_date
from settings import PATH_WINGET_REPOSITORY, PATH_WINGET_REPOSITORY_DB, URL_WINGET_REPOSITORY, PATH_FILES


#SQL-DB
def get_All_Packages_from_DB(search: str = "") -> list:
    download_source_msix()

    with StoreDB() as db:
        packages = db.get_All_Packages_from_DB(search)
    return packages


def check_for_new_Version(packages: list) -> tuple[list[dict], bool]:
    download_source_msix()

    with StoreDB() as db:
        with SQLiteDatabase() as ddb:
            update_status = False
            for p in packages:
                a_v = db.get_Package_Versions(p['PACKAGE_ID'])
                c_v = [v['VERSION'] for v in ddb.get_All_Versions_from_Package(p['PACKAGE_ID'])]
                available_versions = sorted(a_v, key=parse_version, reverse=True)
                current_versions = sorted(c_v, key=parse_version, reverse=True)

                if current_versions and available_versions:
                    available = parse_version(available_versions[0])
                    current = parse_version(current_versions[0])
                    if available > current:
                        p['NEW_VERSION'] = [True, current_versions[0], available_versions[0]]
                        update_status = True
                    else:
                        p['NEW_VERSION'] = [False, current_versions[0], available_versions[0]]
                else:
                    p['NEW_VERSION'] = [False, "", ""]
    return packages, update_status


def get_package_path(package_id: str, version: str) -> tuple[str, str]:
    with StoreDB() as db:
        p_path = db.get_Package_Path(package_id, version)
    return "/".join(p_path), f'{"_".join(p_path)}.yaml'


#Requests, etc.
def download_source_msix(update: bool = False) -> bool:
    if not os.path.exists(PATH_WINGET_REPOSITORY_DB) or update:
        try:
            response = requests.get(f"{URL_WINGET_REPOSITORY}/source.msix", stream=True)
            if response.status_code == 200:
                if not os.path.exists(PATH_WINGET_REPOSITORY):
                    os.makedirs(PATH_WINGET_REPOSITORY)

                f_path = os.path.join(PATH_WINGET_REPOSITORY, "source.msix")
                with open(f_path, "wb") as f:
                    f.write(response.content)

                time.sleep(1)

                with zipfile.ZipFile(f_path, "r") as zip_ref:
                    zip_ref.extractall(PATH_WINGET_REPOSITORY)
                time.sleep(1.5)
                return True
            return False
        except:
            return False
    return False


def get_All_InstallerInfos_from_Manifest(p_path: str, manifest_name: str) -> dict:
    manifest = {}
    m_path = os.path.join(PATH_WINGET_REPOSITORY, "Manifests", manifest_name)

    if os.path.exists(m_path):
        with open(m_path, 'r', encoding='utf-8') as f:
            manifest = yaml.safe_load(f)
    else:
        r = requests.get(f"{URL_WINGET_REPOSITORY}{p_path}")
        if r.status_code == 200:
            manifest = yaml.safe_load(r.text)

            os.makedirs(os.path.join(PATH_WINGET_REPOSITORY, "Manifests"), exist_ok=True)
            with open(m_path, "w", encoding="utf-8") as f:
                yaml.dump(manifest, f, default_flow_style=False, allow_unicode=True)

    if manifest:
        installer_inherit = {
            "InstallerType": ("InstallerType", ''),
            "InstallerSwitches": ("InstallerSwitches", {}),
            "Channel": ("Channel", 'stable'),
            "UpgradeBehavior": ("UpgradeBehavior", 'install'),
            "InstallerLocale": ("PackageLocale", ''),
            "Scope": ("Scope", ''),
            "ProductCode": ("ProductCode", None),
            "UpgradeCode": ("UpgradeCode", None),
            "PackageFamilyName": ("PackageFamilyName", None),
            "AppsAndFeaturesEntries": ("AppsAndFeaturesEntries", None),
        }

        is_empty = lambda v: v is None or v == '' or v == [] or v == {}
        installer = manifest.get("Installers", [])
        for i in installer:
            for key, (root_key, default) in installer_inherit.items():
                if is_empty(i.get(key)):
                    value = manifest.get(root_key)
                    if is_empty(value):
                        value = default
                    if value is not None:
                        i[key] = copy.deepcopy(value)

            for key in ("ProductCode", "UpgradeCode"):
                if is_empty(i.get(key)):
                    for entry in i.get("AppsAndFeaturesEntries") or []:
                        if isinstance(entry, dict) and not is_empty(entry.get(key)):
                            i[key] = entry[key]
                            break

            arp_type = ''
            arp_targets = []
            for entry in i.get("AppsAndFeaturesEntries") or []:
                if isinstance(entry, dict) and not is_empty(entry.get("InstallerType")):
                    arp_type = str(entry["InstallerType"]).strip().lower()
                    break

            if arp_type:
                if not is_empty(i.get("UpgradeCode")):
                    arp_targets = ["UpgradeCode"]
                elif not is_empty(i.get("ProductCode")):
                    arp_targets = ["ProductCode"]

            for entry in i.get("AppsAndFeaturesEntries") or []:
                if isinstance(entry, dict):
                    for key in ("ProductCode", "UpgradeCode"):
                        if is_empty(entry.get(key)) and not is_empty(i.get(key)):
                            entry[key] = i[key]

            for key in arp_targets:
                i[key] = f"{i[key]},{arp_type}"

            if i["InstallerType"].upper() == "ZIP":
                if len(i.get("NestedInstallerFiles", [])) == 0:
                    i["NestedInstallerFiles"] = manifest.get('NestedInstallerFiles', [])
                if i.get("NestedInstallerType", '') == '':
                    i["NestedInstallerType"] = manifest.get('NestedInstallerType', '')

        localizations = []
        for loc in manifest.get("Localization", []):
            localizations.append({
                "Locale": loc.get("PackageLocale", ""),
                "Packagename": loc.get("PackageName", manifest.get("PackageName", "")),
                "Description": loc.get("ShortDescription", ""),
                "Publisher": loc.get("Publisher", manifest.get("Publisher", "")),
            })

        p_infos = {"Packagename": manifest.get("PackageName", ""), "Author": manifest.get("Author", ""),
                   "Description": manifest.get("ShortDescription", ""), "Locale": manifest.get("PackageLocale", "en-US"),
                   "Scope": manifest.get("Scope", "machine"), "Installers": installer, "Localizations": localizations,
                   "Icons": manifest.get("Icons", [])}
        return p_infos
    return manifest


def download_file(url: str, filename: str, return_filestorage: bool = False) -> bool | FileStorage:
    with requests.get(url, stream=True, timeout=60) as response:
        if response.status_code != 200:
            return False

        if return_filestorage:
            buffer = BytesIO()
            for chunk in response.iter_content(chunk_size=8192):
                buffer.write(chunk)
            buffer.seek(0)
            return FileStorage(stream=buffer, filename=filename)
        else:
            with open(Path(PATH_FILES) / filename, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            return True


def load_store_manifest(package_id: str, version: str) -> tuple[dict | None, str | None]:
    package_path, manifest_name = get_package_path(package_id, version)
    if not package_path:
        return None, "No package found in store!"

    p_infos = get_All_InstallerInfos_from_Manifest(package_path, manifest_name)
    if not p_infos or not p_infos.get('Installers'):
        return None, "No versions found!"

    return p_infos, None


def build_installer_overview(db, package_id: str, version: str, p_infos: dict) -> list[dict]:
    overview = []

    for idx, installer in enumerate(p_infos['Installers']):
        already_exists = not db.check_Package_Version_not_exists(
            package_id, version,
            db.get_Locale_ID_by_Value(installer.get('InstallerLocale', 'en-US')),
            installer.get('Architecture', 'x64'),
            installer.get('InstallerType', 'msi'),
            installer.get('Scope', '')
        )
        entry = dict(installer)
        entry['INDEX'] = idx
        entry['EXISTS'] = already_exists
        overview.append(entry)
    return overview


def add_installer_version(db, package_id: str, version: str, installer: dict) -> tuple[bool, str]:
    locale_id = db.get_Locale_ID_by_Value(installer.get('InstallerLocale', 'en-US'))

    version_already_exists = not db.check_Package_Version_not_exists(
        package_id, version, locale_id,
        installer.get('Architecture', 'x64'),
        installer.get('InstallerType', 'msi'),
        installer.get('Scope', 'machine')
    )
    if version_already_exists:
        return False, "Version already exists!"

    expected_hash = installer.get('InstallerSha256', '')
    if not isinstance(expected_hash, str) or len(expected_hash) != 64:
        return False, "Missing or invalid installer SHA256!"

    version_uid = str(uuid4())
    filename = f"{version_uid}.{installer['InstallerUrl'].split('.')[-1]}"

    try:
        if not download_file(installer['InstallerUrl'], filename):
            return False, "Error downloading installer!"
    except Exception:
        return False, "Error downloading installer!"

    file_path = Path(PATH_FILES) / filename
    with open(file_path, 'rb') as f:
        file_hash = sha256(f.read()).hexdigest()
    if file_hash.lower() != expected_hash.lower():
        file_path.unlink(missing_ok=True)
        return False, "Installer SHA256 mismatch!"

    db.add_Package_Version(
        package_id, version, locale_id,
        installer.get('Architecture', 'x64'),
        installer.get('InstallerType', 'msi'),
        filename, file_hash,
        installer.get('Scope', 'machine'),
        version_uid,
        installer.get('NestedInstallerType', ''),
        installer.get('ProductCode', ''),
        installer.get('UpgradeCode', ''),
        installer.get('PackageFamilyName', ""),
        installer.get('Channel', "stable"),
        installer.get('UpgradeBehavior', 'install')
    )

    if installer.get('InstallerType', '') == "zip":
        for i_n in installer.get('NestedInstallerFiles', []):
            for key, value in i_n.items():
                db.add_Nested_Installer(version_uid, key, value)

    for switch_key in ["Silent", "SilentWithProgress", "Interactive", "InstallLocation", "Log", "Upgrade", "Custom", "Repair"]:
        switch_value = installer.get('InstallerSwitches', {}).get(switch_key, "")
        if switch_value:
            db.add_Package_Version_Switch(version_uid, switch_key, switch_value)

    return True, "OK"


#Update
def update_store_db(days: int = 2):
    if not os.path.exists(PATH_WINGET_REPOSITORY_DB):
        return

    edit_date = get_file_edit_date(PATH_WINGET_REPOSITORY_DB)
    diff = datetime.datetime.now() - edit_date

    if diff.days >= days:
        download_source_msix(True)
