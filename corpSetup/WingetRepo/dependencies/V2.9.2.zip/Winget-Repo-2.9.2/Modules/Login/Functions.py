from werkzeug.security import check_password_hash

from Modules.Database.Database import SQLiteDatabase


def check_Credentials(username: str, password: str) -> tuple[bool, str]:
    with SQLiteDatabase() as db:
        data = db.check_User_Credentials(username)

    if data and check_password_hash(data['PW'], password):
        return True, data['ID']
    else:
        check_password_hash("fake_hash_standard", "fake_password")
    return False, ""


def check_Rights(userid: str, endpoint: str) -> bool:
    with SQLiteDatabase() as db:
        data = db.check_User_Authentication(userid)

    if len(data) > 0:
        if data.get(endpoint.upper(), 0) == 1:
            return True
    return False
