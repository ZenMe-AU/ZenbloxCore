import ipaddress
import configparser
import json
import os
import random
import sqlite3
import string
import dns.resolver
import dns.reversename
import zlib
import io
import shutil
import sys
import re
import urllib.request
import urllib.error

from datetime import datetime
from pathlib import Path
from werkzeug.datastructures import headers
from io import StringIO, BytesIO
from settings import PATH_FILES, PATH_CERTIFICATES, PATH_PLUGINS, URL_WINGET_REPOSITORY
from itsdangerous import base64_decode, URLSafeTimedSerializer
from PIL import Image, ImageChops

from Modules.Database.Upgrade import migrate_database


def all_to_dict(data: list, header_data: tuple) -> list:
    if len(data) > 0:
        header = []
        for item in header_data:
            header.extend(value for value in item if value is not None)
        data = [dict(zip(header, d)) for d in data]
        return data
    return []


def row_to_dict(row: tuple, header_data: tuple) -> dict:
    if row is not None and len(row) > 0:
        return {desc[0]: val for desc, val in zip(header_data, row)}
    else:
        return {}


def split_sql_data(data: list | dict, seperator: str = ",") -> list | dict:
    def split_item(item: dict) -> dict:
        arp_installer_type = ''
        if seperator in item.get('PRODUCTCODE', ''):
            productcode, arp_installer_type = item['PRODUCTCODE'].split(seperator, 1)
            item['PRODUCTCODE'] = productcode.strip()
            arp_installer_type = arp_installer_type.strip()

        if seperator in item.get('UPGRADECODE', ''):
            upgradecode, upgrade_arp_type = item['UPGRADECODE'].split(seperator, 1)
            item['UPGRADECODE'] = upgradecode.strip()
            if upgrade_arp_type.strip():
                arp_installer_type = upgrade_arp_type.strip()

        item['ARP_INSTALLER_TYPE'] = arp_installer_type
        return item

    if isinstance(data, dict):
        return split_item(data)
    return [split_item(item) for item in data]


def get_serializer(secret_key: str) -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(secret_key)


def get_ip_from_hostname(hostname: str, suffix: str, dns_server: str) -> str:
    resolver = dns.resolver.Resolver()
    resolver.nameservers = [dns_server]

    try:
        answers = resolver.resolve(hostname, 'A')
        for rdata in answers:
            return rdata.address
    except Exception:
        pass

    if suffix and not hostname.endswith(suffix):
        fqdn = f"{hostname}.{suffix}".rstrip(".")
        try:
            answers = resolver.resolve(fqdn, 'A')
            for rdata in answers:
                return rdata.address
        except Exception:
            pass
    return ""


def get_hostname_from_ip_dns(ip_address: str, dns_server: str) -> str:
    try:
        rev_name = dns.reversename.from_address(ip_address)
        resolver = dns.resolver.Resolver()
        resolver.nameservers = [dns_server]
        answer = resolver.resolve(rev_name, "PTR")
        full_hostname = str(answer[0]).rstrip(".")
        short_hostname = full_hostname.split(".")[0]
        return short_hostname
    except Exception:
        return ""


def is_ip_address(text: str) -> bool:
    try:
        ipaddress.ip_address(text)
        return True
    except ValueError:
        return False


def check_Internet_Connection() -> bool:
    try:
        req = urllib.request.Request(URL_WINGET_REPOSITORY, method="HEAD")
        urllib.request.urlopen(req, timeout=3)
        return True
    except urllib.error.HTTPError:
        return True
    except (urllib.error.URLError, OSError):
        return False


def get_Auth_Token_from_Header(header: headers) -> str:
    try:
        client_auth_token = json.loads(header.get('Windows-Package-Manager').replace("'", '"'))
        client_auth_token = client_auth_token.get("Token")
    except:
        client_auth_token = ""
    return client_auth_token


def parse_version(version_str: str) -> tuple:
    parts = version_str.split('.')
    numeric_parts = []

    for p in parts:
        try:
            numeric_parts.append(int(p))
        except ValueError:
            break

    if not numeric_parts:
        return (-1,)

    while len(numeric_parts) < 3:
        numeric_parts.append(0)
    return tuple(numeric_parts)


def generate_Client_INI(token: str, host: str) -> BytesIO:
    config = configparser.ConfigParser()
    config['Settings'] = {
        'URL': f'https://{host}',
        'Token': token,
        'Repo': 'Winget-Repo'
    }

    ini_stream = BytesIO()
    temp_stream = StringIO()
    config.write(temp_stream)
    data = temp_stream.getvalue().encode('utf-8')

    ini_stream.write(data)
    ini_stream.seek(0)
    return ini_stream


def get_file_edit_date(path: str) -> datetime:
    file = Path(path)
    mtime = file.stat().st_mtime
    return datetime.fromtimestamp(mtime)


def _make_way(path):
    if os.path.exists(path):
        suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        base, ext = os.path.splitext(path)
        new_path = f"{base}_{suffix}{ext}"
        os.rename(path, new_path)
        print(f"[STARTUP] Existing old database file found – renamed to {os.path.basename(new_path)}")


def start_up_check():
    if not os.path.exists(PATH_FILES):
        os.makedirs(PATH_FILES)
    if not os.path.exists(PATH_CERTIFICATES):
        os.makedirs(PATH_CERTIFICATES)
    if not os.path.exists(PATH_PLUGINS):
        os.makedirs(PATH_PLUGINS)

    base_dir = sys.path[0]
    seed_db = os.path.join(base_dir, "Modules", "Database", "Database.db")
    live_db = os.path.join(base_dir, "Config", "Database", "Database.db")
    old_db = os.path.join(base_dir, "Config", "Database", "old_database.db")

    conn = sqlite3.connect(seed_db)
    seed_version = conn.execute("PRAGMA user_version").fetchone()[0]
    conn.close()

    os.makedirs(os.path.dirname(live_db), exist_ok=True)
    if os.path.exists(live_db):
        conn = sqlite3.connect(live_db)
        old_version = conn.execute("PRAGMA user_version").fetchone()[0]
        conn.close()

        if old_version < seed_version:
            _make_way(old_db)
            _make_way(old_db.replace(".db", "_migrated.db"))

            print("[STARTUP] old_database.db found – running migration...")
            os.rename(live_db, live_db.replace("Database.db", "old_database.db"))
            shutil.copy2(seed_db, live_db)
            migrate_database(old_db_path=old_db, new_db_path=live_db)
            os.rename(old_db, old_db.replace(".db", "_migrated.db"))
            print("[STARTUP] Migration complete. old_database.db renamed to old_database_migrated.db.")
            return
        elif old_version >= seed_version:
            print("[STARTUP] Existing database found – starting normally...")
            return
    print("[STARTUP] No database found – initializing from seed...")
    shutil.copy2(seed_db, live_db)


def decode_flask_cookie(cookie) -> dict:
    try:
        compressed = False
        payload = cookie

        if payload.startswith('.'):
            compressed = True
            payload = payload[1:]

        data = payload.split(".")[0]

        data = base64_decode(data)
        if compressed:
            data = zlib.decompress(data)

        return json.loads(data.decode("utf-8"))
    except Exception as e:
        return {}


def _autocrop(img: Image.Image, tolerance: int = 10) -> Image.Image:
    rgba = img.convert("RGBA")
    alpha_bbox = rgba.split()[-1].getbbox()
    background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    diff = ImageChops.difference(rgba.convert("RGB"), background.convert("RGB"))
    diff = ImageChops.add(diff, diff, 2.0, -tolerance)
    white_bbox = diff.getbbox()

    boxes = [b for b in (alpha_bbox, white_bbox) if b is not None]
    if not boxes:
        return img

    left = min(b[0] for b in boxes)
    upper = min(b[1] for b in boxes)
    right = max(b[2] for b in boxes)
    lower = max(b[3] for b in boxes)
    return rgba.crop((left, upper, right, lower))


def process_package_logo(file, filename, size=(621, 591)) -> bool:
    try:
        file_obj = getattr(file, "file", None)
        if file_obj is None:
            file_obj = getattr(file, "stream", None)
        if file_obj is None:
            file_obj = file

        with Image.open(io.BytesIO(file_obj.read())) as source:
            if source.format == "ICO":
                source.size = max(source.info["sizes"], key=lambda dimensions: dimensions[0] * dimensions[1])
                img = source.convert("RGBA")
            else:
                img = _autocrop(source.convert("RGBA"))
        img.thumbnail(size, Image.Resampling.LANCZOS)

        output_buffer = io.BytesIO()
        img.save(output_buffer, format="PNG", optimize=True)
        final_content = output_buffer.getvalue()

        with open(filename, "wb") as out_file:
            out_file.write(final_content)
        return True
    except Exception as e:
        return False


def convert_old_log(old_text: str) -> str:
    if not old_text:
        return ""

    match = re.match(r"^Client: (?P<name>.+?) downloaded the following package: (?P<package_id>.+?) - (?P<version>.+)$", old_text)
    if match:
        return json.dumps({
            "Client": match.group("name"),
            "Package": match.group("package_id"),
            "Version": match.group("version"),
        })

    match = re.match(r"^Client: (?P<name>.+?) did something unknown!$", old_text)
    if match:
        return json.dumps({
            "Client": match.group("name"),
            "Package": "Unknown",
            "Version": "",
        })
    return ""
