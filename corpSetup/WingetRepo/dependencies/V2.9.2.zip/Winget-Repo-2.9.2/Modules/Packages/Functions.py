import shutil

from pathlib import Path
from uuid import uuid4
from hashlib import sha256
from itertools import groupby

from Modules.Database.Database import SQLiteDatabase
from Modules.Files.Functions import delete_File
from Modules.Functions import parse_version, process_package_logo
from settings import PATH_LOGOS, PATH_FILES


# ------------------------------
# PACKAGE MANAGEMENT
# ------------------------------
def add_package_service(data: dict, file=None):
    package_id = data.get("package_id", str(uuid4()))
    if len(package_id) == 0:
        package_id = str(uuid4())

    if file:
        logo_path = f"{package_id}.png"
        dest_path = Path(PATH_LOGOS) / logo_path
        process_package_logo(file, dest_path)
    else:
        logo_path = "dummy.png"

    with SQLiteDatabase() as db:
        status = db.add_Package(package_id, data.get("package_name", "")[:50], data.get("package_publisher", "")[:50], data.get("package_description", "")[:200], logo_path)
    return status, package_id


def edit_package_service(package_id: str, data: dict, file=None):
    with SQLiteDatabase() as db:
        if not db.check_Package_exists(package_id):
            return False, "Package not found"

        package = db.get_Package_by_ID(package_id)
        if data.get("reset_logo") == "1":
            logo_path = "dummy.png"
        elif file:
            logo_path = f"{package_id}.png"
            dest_path = Path(PATH_LOGOS) / logo_path
            process_package_logo(file, dest_path)
        else:
            logo_path = package['PACKAGE_LOGO']

        status = db.add_Package(package_id, data.get("package_name", package['PACKAGE_NAME'])[:50], data.get("package_publisher", package['PACKAGE_PUBLISHER'])[:50], data.get("package_description", package['PACKAGE_DESCRIPTION'])[:200], logo_path, int(data.get("package_active", package['PACKAGE_ACTIVE'])))
    return status, package_id


def delete_package_service(package_id: str):
    with SQLiteDatabase() as db:
        if not db.check_Package_exists(package_id):
            return False

        for f in db.get_All_Versions_from_Package(package_id):
            delete_File(f['INSTALLER_URL'])
            db.delete_Package_Version(f['UID'])

        delete_File(f"{package_id}.png", PATH_LOGOS)
        db.delete_Package(package_id)
    return True


# ------------------------------
# PACKAGE VERSION MANAGEMENT
# ------------------------------
def add_package_version_service(package_id: str, data: dict, file=None):
    with SQLiteDatabase() as db:
        if not db.check_Package_exists(package_id):
            return False, "Package doesn't exist"

        version_uid = str(uuid4())
        filename = f"{version_uid}.{file.filename.split('.')[-1]}" if file else None
        file_type = data.get('file_type', 'msi').lower()

        if file and db.check_Package_Version_not_exists(package_id, data.get("package_version", "")[:25], data.get("package_local", 1), data.get("file_architect", ""), file_type, data.get("file_scope", "")):
            f_path = Path(PATH_FILES) / filename
            file_obj = getattr(file, "file", None)
            if file_obj is None:
                file_obj = getattr(file, "stream", None)
            if file_obj is None:
                file_obj = file

            with open(f_path, "wb") as out_file:
                shutil.copyfileobj(file_obj, out_file)

            try:
                file_obj.seek(0)
            except:
                pass

            with open(f_path, 'rb') as f:
                readable_hash = sha256(f.read()).hexdigest()

            p_locale = data.get("package_local", "en-US")
            if not str(p_locale).isnumeric():
                p_locale = db.get_Locale_ID_by_Value(p_locale)

            product_code = data.get('productcode', '').strip()
            upgrade_code = data.get('upgradecode', '').strip()
            arp_installer_type = data.get('arp_installer_type', '').strip()
            if arp_installer_type:
                if upgrade_code:
                    upgrade_code = f"{upgrade_code},{arp_installer_type}"
                elif product_code:
                    product_code = f"{product_code},{arp_installer_type}"

            status = db.add_Package_Version(package_id, data.get("package_version", "")[:25], p_locale, data.get("file_architect", ""), file_type, filename, readable_hash, data.get("file_scope", ""), version_uid, data.get('file_type_nested', '').lower(), product_code, upgrade_code, data.get('package_family_name', ""), data.get('channel', "stable").lower(), data.get('upgrades', "install"))

            if isinstance(data.get('file_nested_path'), list):
                if status and file_type == "zip":
                    for fnp in data.get('file_nested_path'):
                        db.add_Nested_Installer(version_uid, 'RelativeFilePath', fnp)
            else:
                if status and file_type == "zip" and len(data.get('file_nested_path', '')) > 0:
                    db.add_Nested_Installer(version_uid, 'RelativeFilePath', data.get('file_nested_path', ''))

            switches = {key.replace("switch_", ""): value for key, value in data.items() if key.startswith('switch_')}
            for s in ["Silent", "SilentWithProgress", "Interactive", "InstallLocation", "Log", "Upgrade", "Custom", "Repair"]:
                if s in switches and switches[s] != "":
                    db.add_Package_Version_Switch(version_uid, s, switches[s])

            dep_map = {
                "WindowsFeatures": data.get("dep_windows_features", []),
                "WindowsLibraries": data.get("dep_windows_libraries", []),
                "ExternalDependencies": data.get("dep_external", []),
            }
            for dep_type, entries in dep_map.items():
                for value in entries:
                    if value.strip():
                        db.add_Package_Version_Dependency(version_uid, dep_type, value.strip(), None)

            for pkg_dep in data.get("dep_package_dependencies", []):
                identifier = pkg_dep.get("PackageIdentifier", "").strip()
                min_version = pkg_dep.get("MinimumVersion", "").strip() or None
                if identifier:
                    db.add_Package_Version_Dependency(version_uid, "PackageDependencies", identifier, min_version)

            delete_overflow_package_versions(package_id, db)
            return status, version_uid
        else:
            return False, "Package/Font version already exists or file missing"


def edit_package_version_service(version_id: str, data: dict):
    active_value = data.get('active')
    if isinstance(active_value, str):
        active_value = active_value.lower() in ('1', 'true', 'on')
    else:
        active_value = bool(active_value)

    with SQLiteDatabase() as db:
        db.toggle_Package_Version(version_id, active_value)
    return True


def delete_package_versions_service(version_ids: list):
    with SQLiteDatabase() as db:
        for vid in version_ids:
            url = db.get_specfic_Versions_from_Package(vid)
            if url:
                delete_File(url['INSTALLER_URL'])
                db.delete_Package_Version(vid)
    return True


def delete_overflow_package_versions(package_id: str, db):
    current_settings = db.get_winget_Settings()
    keep_setting = current_settings.get('ONLY_KEEP_CERTAIN_VERSIONS', '0')
    if str(keep_setting).isdigit() and int(keep_setting) > 0:
        db.commit()
        keep_count = int(keep_setting)
        current_versions = get_package_versions_service(package_id)
        grouped = [list(g) for _, g in groupby(current_versions, key=lambda x: x['VERSION'])]

        if len(grouped) > keep_count:
            versions_to_delete = [v['UID'] for group in grouped[keep_count:] for v in group]
            delete_package_versions_service(versions_to_delete)


# ------------------------------
# GETTER Functions
# ------------------------------
def get_package_service(package_id: str):
    with SQLiteDatabase() as db:
        package = db.get_Package_by_ID(package_id) if db.check_Package_exists(package_id) else None
    return package


def get_all_packages_and_locales_service():
    with SQLiteDatabase() as db:
        packages = db.get_All_Packages()
        locales = db.get_All_Locales()
    return packages, locales


def get_package_versions_service(package_id: str):
    with SQLiteDatabase() as db:
        if not db.check_Package_exists(package_id):
            return []

        versions = db.get_All_Versions_from_Package(package_id)
        versions = sorted(versions, key=lambda x: parse_version(x["VERSION"]), reverse=True)

        for v in versions:
            v['SWITCHES'] = db.get_Package_Switche(v['UID'])
            v['NESTED_FILES'] = db.get_Nested_Installer(v['UID'])
            v['DEPENDENCIES'] = {
                "WINDOWS_FEATURES": db.get_Package_Version_Dependencies(v['UID'], "WindowsFeatures"),
                "WINDOWS_LIBRARIES": db.get_Package_Version_Dependencies(v['UID'], "WindowsLibraries"),
                "EXTERNAL":          db.get_Package_Version_Dependencies(v['UID'], "ExternalDependencies"),
                "PACKAGES":          db.get_Package_Version_Dependencies(v['UID'], "PackageDependencies"),
            }
    return versions
