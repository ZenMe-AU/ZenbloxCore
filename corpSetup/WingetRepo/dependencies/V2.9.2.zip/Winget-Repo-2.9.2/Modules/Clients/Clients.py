import json

from flask import Blueprint, render_template, redirect, url_for, request, flash, send_file, current_app
from uuid import uuid4

from Modules.Database.Database import SQLiteDatabase
from Modules.Functions import get_ip_from_hostname, generate_Client_INI, convert_old_log
from Modules.Login.Login import logged_in, authenticate

client_bp = Blueprint('client_bp', __name__, template_folder='templates', static_folder='static')


@client_bp.route('/', methods=['GET'])
@logged_in
@authenticate
def index():
    with SQLiteDatabase() as db:
        clients = db.get_All_Clients()
        groups = db.get_All_Blacklist_Groups()
    return render_template("index_clients.html", clients=clients, groups=groups)


@client_bp.route('/add', methods=['POST'])
@logged_in
@authenticate
def add_client():
    name = request.form.get('client_name', "")

    if len(name) > 0:
        dev_mode = current_app.config.get('dev_mode', False)

        if dev_mode:
            ip = "127.0.0.1"
            name = "LOCALHOST"
        else:
            with SQLiteDatabase() as db:
                settings = db.get_winget_Settings()

            if settings.get('CLIENT_AUTHENTICATION_DNS_USAGE', "1") == "1":
                ip = get_ip_from_hostname(name, settings.get('DNS_SUFFIX', ''), settings.get('DNS_SERVER', '192.168.1.1'))
            else:
                ip = "127.0.0.1"

        if len(ip) > 0:
            c_id = str(uuid4())

            with SQLiteDatabase() as db:
                status = db.add_New_Client(c_id, name.upper()[:25], ip, str(uuid4()))

            if status:
                flash("Client was added successfully!", "success")
                return redirect(url_for("client_bp.setup_client", client_id=c_id))
            else:
                flash("Hostname alreay exists!", "error")
        else:
            flash("Can't get ip from entered hostname! Check the input or dns config!", "error")
    else:
        flash("Error. No Data found!", "error")
    return redirect(url_for('client_bp.index'))


@client_bp.route('/block/<client_id>', methods=['POST'])
@logged_in
@authenticate
def block_client(client_id):
    with SQLiteDatabase() as db:
        client = db.get_Client_by_ID(client_id)

        if client:
            if client['ENABLED'] == 1:
                status = 0
                flash("Client successfully disabled!", "success")
            else:
                status = 1
                flash("Client successfully enabled!", "success")

            db.update_Client_Enable_Status(client_id, status)
        else:
            flash("Client not found!", "error")
    return redirect(url_for("client_bp.index"))


@client_bp.route('/delete/<client_id>/<auth_token>', methods=['POST'])
@logged_in
@authenticate
def delete_client(client_id, auth_token):
    if len(client_id) > 0 and len(auth_token) > 0:
        with SQLiteDatabase() as db:
            db.delete_Client(client_id, auth_token)
        flash("Client was removed successfully!", "success")
    else:
        flash("Error. No Data found!", "error")
    return redirect(url_for('client_bp.index'))


@client_bp.route('/setup/<client_id>', methods=['GET', 'POST'])
@logged_in
@authenticate
def setup_client(client_id):
    with SQLiteDatabase() as db:
        data = db.get_Client_by_ID(client_id)
        settings = db.get_winget_Settings()

    if data:
        auth_s = settings.get('CLIENT_AUTHENTICATION', '0')
        if request.method == "POST":
            token = ''
            if auth_s == "1":
                token = data.get('TOKEN', '')
            ini = generate_Client_INI(token, request.host)
            return send_file(ini, as_attachment=True, download_name='config.ini', mimetype='text/plain')

        return render_template("index_clients_setup.html", client=data, authentication=auth_s, host_url=request.host)
    flash("No client found!", "error")
    return redirect(url_for("client_bp.index"))


@client_bp.route('/logs', methods=['GET'])
@logged_in
@authenticate
def view_logs():
    selected_client = request.args.get('client_id', 'all')
    selected_package = request.args.get('package_id', 'all')

    with SQLiteDatabase() as db:
        if selected_client and selected_client.lower() != 'all':
            raw_logs = db.get_Logs_for_Client(selected_client)
        else:
            raw_logs = db.get_all_Logs()

        packages = db.get_All_Packages()
        clients = db.get_All_Clients()

    client_lookup = {c["UID"]: c["NAME"] for c in clients}
    logs = []
    for entry in raw_logs:
        message_raw = entry["LOG_MESSAGE"]
        message_data = None

        try:
            parsed = json.loads(message_raw)
            if isinstance(parsed, dict):
                message_data = parsed
        except (TypeError, ValueError):
            pass

        if message_data is None:
            converted = convert_old_log(message_raw)
            if converted:
                try:
                    message_data = json.loads(converted)
                except (TypeError, ValueError):
                    message_data = None

        if message_data is None:
            message_data = {"Client": None, "Package": "Unknown", "Version": ""}

        client_id = entry["CLIENT_ID"]
        client_name = client_lookup.get(client_id) or message_data.get("Client") or client_id
        if selected_package and selected_package.lower() != 'all':
            if message_data.get("Package") != selected_package:
                continue

        logs.append({
            "TIMESTAMP": entry["TIMESTAMP"],
            "LOG_TYPE": entry["LOG_TYPE"],
            "LOG_MESSAGE": message_raw,
            "MESSAGE_DATA": message_data,
            "CLIENT_ID": client_id,
            "CLIENT_NAME": client_name,
        })
    return render_template("index_clients_logs.html", logs=logs, clients=clients, selected_client=selected_client, packages=packages, selected_package=selected_package)


@client_bp.route('/logs/<client_id>/clear', methods=['GET'])
@logged_in
@authenticate
def clear_logs(client_id):
    with SQLiteDatabase() as db:
        if client_id.lower() == "all":
            db.remove_all_logs()
        else:
            db.remove_logs(client_id)

    flash("Successfully cleared logs!", "success")
    return redirect(url_for("client_bp.view_logs", client_id=client_id))


@client_bp.route('/blacklist/<client_id>/<auth_token>', methods=['GET', 'POST'])
@logged_in
@authenticate
def blacklist(client_id, auth_token):
    with SQLiteDatabase() as db:
        if request.method == 'POST':
            selected_packages = request.form.getlist('blacklist')
            selected_groups = request.form.getlist('group_blacklist')

            db.update_Blacklist_Package(auth_token, selected_packages)
            db.update_Blacklist_Groups_Clients(auth_token, selected_groups)

            flash("Blacklist successfully updated!", "success")
            return redirect(url_for('client_bp.index'))

        client = db.get_Client_by_ID(client_id)

        if not client:
            flash("Client not found!", "error")
            return redirect(url_for('client_bp.index'))

        packages = db.get_All_Packages()
        blacklisted_packages = db.get_Blacklist_for_client(auth_token, False)
        blacklist_groups = db.get_All_Blacklist_Groups()
        blacklisted_groups = db.get_Blacklist_Groups_for_Client(auth_token)

    if len(packages) == 0:
        flash("No packages found!", "error")
        return redirect(url_for('client_bp.index'))

    return render_template('index_clients_blacklist.html', client=client, packages=packages, blacklisted_packages=blacklisted_packages, blacklist_groups=blacklist_groups, blacklisted_groups=blacklisted_groups)


@client_bp.route('/blacklist/groups/<action>', methods=['GET', 'POST'])
@logged_in
@authenticate
def blacklist_groups(action):
    action = action.upper()
    if action not in ("CREATE", "EDIT"):
        flash("Action is not available!", "error")
        return redirect(url_for('client_bp.index'))

    with SQLiteDatabase() as db:
        if request.method == 'POST':
            g_id = request.form.get('group_id', str(uuid4()))
            group_name = request.form.get('group_name', 'Dummy')
            if len(group_name) >= 3:
                selected_packages = request.form.getlist('blacklist')
                db.insert_update_Blacklist_Group(g_id, group_name[:30], selected_packages)

                if action == "CREATE":
                    flash("Blacklist group successfully created!", "success")
                else:
                    flash("Blacklist group successfully updated!", "success")
            else:
                flash("Blacklist group name is to short!", "error")
            return redirect(url_for('client_bp.index'))

        packages = db.get_All_Packages()

        if action == "EDIT":
            g_id = request.args.get('group_id', '')

            if "remove" in request.args:
                db.remove_Blacklist_Group(g_id)
                flash("Blacklist group successfully removed!", "success")
                return redirect(url_for('client_bp.index'))

            group = db.get_Blacklist_Group(g_id)
            blacklisted_packages = db.get_Packages_from_Blacklist_Group(g_id)

            if len(group) == 0:
                flash("Group not found!", "error")
                return redirect(url_for('client_bp.index'))

            return render_template('index_clients_blacklist_groups.html', packages=packages, action=action, group=group, blacklisted_packages=blacklisted_packages)
        else:
            return render_template('index_clients_blacklist_groups.html', packages=packages, action=action)
