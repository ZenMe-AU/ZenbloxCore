import ipaddress
import os
import json

from flask import url_for
from datetime import datetime
from hashlib import sha256

from Modules.Database.Database import SQLiteDatabase
from Modules.Functions import get_hostname_from_ip_dns
from settings import PATH_LOGOS


def generate_search_Manifest(search_text: str, match_typ: str, match_field: str, auth_token: str = "") -> list:
    with SQLiteDatabase() as db:
        packages = db.search_packages(search_text, match_typ, match_field)

        if auth_token != "":
            blacklist = db.get_Blacklist_for_client(auth_token)
            packages = [p for p in packages if p['PACKAGE_ID'] not in blacklist]

        data = []
        for p in packages:
            versions = []

            for d in db.get_All_Versions_from_Package(p['PACKAGE_ID'], True):
                version_info = {
                    "PackageVersion": d['VERSION'],
                    #"Channel": d['CHANNEL'],
                    "PackageFamilyNames": [],
                    "ProductCodes": [],
                    "UpgradeCodes": [],
                    "AppsAndFeaturesEntryVersions": []
                }

                if len(d['PRODUCTCODE']) > 0:
                    version_info["ProductCodes"] = [d['PRODUCTCODE']]

                if len(d['UPGRADECODE']) > 0:
                    version_info["UpgradeCodes"] = [d['UPGRADECODE']]

                if len(d['PACKAGE_FAMILY_NAME']) > 0:
                    version_info["PackageFamilyNames"] = [d['PACKAGE_FAMILY_NAME']]

                versions.append(version_info)

            temp = {
                "PackageIdentifier": p['PACKAGE_ID'],
                "PackageName": p['PACKAGE_NAME'],
                "Publisher": p['PACKAGE_PUBLISHER'],
                "Versions": versions
            }

            if len(temp["Versions"]) > 0:
                data.append(temp)
    return data


def generate_Installer_Manifest(package_id: str, version: str = None, channel: str = None, auth_token: str = "", serializer = None, use_serializer: bool = True) -> dict:
    with SQLiteDatabase() as db:
        package = db.get_specific_Package(package_id, version, channel)
        blacklist = db.get_Blacklist_for_client(auth_token)

        versions = []
        if package and package['PACKAGE_ID'] not in blacklist:
            for version_group in package['VERSIONS']:
                version_info = _build_version_info(version_group, package, db)
                if version_info:
                    versions.append(version_info)

    if package and package['PACKAGE_ID'] not in blacklist:
        for v_info in versions:
            for inst in v_info.get("Installers", []):
                file_url = inst["InstallerUrl"]
                if use_serializer and serializer:
                    file_url = serializer.dumps(file_url)
                inst["InstallerUrl"] = url_for("winget_routes.download", package_name=file_url, _external=True)

            for icon in v_info.get("DefaultLocale", {}).get("Icons", []):
                logo_url = icon["IconUrl"]
                if use_serializer and serializer:
                    logo_url = serializer.dumps(logo_url)
                icon["IconUrl"] = url_for("winget_routes.get_package_logo", logo_name=logo_url, _external=True)

        r_data = {
            "Data": {
                "PackageIdentifier": package['PACKAGE_ID'],
                "Versions": versions
            }
        }
    else:
        r_data = {}
    return r_data


def _build_version_info(version_group: list, package: dict, db: SQLiteDatabase) -> dict:
    first_installer = version_group[0]

    installers = []
    for installer_data in version_group:
        installer = _build_installer_entry(installer_data, db)
        if installer:
            installers.append(installer)

    icon = []
    p_logo = package.get('PACKAGE_LOGO', '')
    if len(p_logo) > 0:
        if not os.path.exists(os.path.join(PATH_LOGOS, p_logo)):
            p_logo = "dummy.png"

        if p_logo.lower() != "dummy.png":
            with open(os.path.join(PATH_LOGOS, p_logo), 'rb') as f:
                logo_hash = sha256(f.read()).hexdigest()
            icon.append({
                "IconUrl": p_logo,
                "IconFileType": "png",
                "IconResolution": "custom",
                "IconTheme": "default",
                "IconSha256": logo_hash
            })

    return {
        "PackageVersion": first_installer.get('VERSION', '0.0.0.0'),
        # "Channel": first_installer.get('CHANNEL', 'stable')
        "DefaultLocale": {
            "PackageLocale": first_installer.get('LOCALE', 'en-US'),
            "Publisher": package.get('PACKAGE_PUBLISHER', ''),
            "PackageName": package.get('PACKAGE_NAME', ''),
            "ShortDescription": package.get('PACKAGE_DESCRIPTION', ''),
            "Icons": icon
        },
        "Installers": installers
    }


def _build_installer_entry(installer_data: dict, db: SQLiteDatabase) -> dict:
    installer = {
        "Architecture": installer_data.get('ARCHITECTURE', 'x64'),
        "InstallerType": installer_data.get('INSTALLER_TYPE', ''),
        "InstallerUrl": installer_data.get('INSTALLER_URL', ''),
        "InstallerSha256": installer_data.get('INSTALLER_SHA256', ''),
        "Scope": installer_data.get('INSTALLER_SCOPE', 'machine'),
        "UpgradeBehavior": installer_data.get('UPGRADEBEHAVIOR', 'install'),
        "InstallerSwitches": db.get_Package_Switche(installer_data.get('UID')),
        "Dependencies": {
            "WindowsFeatures": db.get_Package_Version_Dependencies(installer_data.get('UID'), "WindowsFeatures"),
            "WindowsLibraries": db.get_Package_Version_Dependencies(installer_data.get('UID'), "WindowsLibraries"),
            "PackageDependencies": db.get_Package_Version_Dependencies(installer_data.get('UID'), "PackageDependencies"),
            "ExternalDependencies": db.get_Package_Version_Dependencies(installer_data.get('UID'), "ExternalDependencies")
        }
    }

    package_family_name = installer_data.get('PACKAGE_FAMILY_NAME', '')
    if package_family_name:
        installer["PackageFamilyName"] = package_family_name

    product_code = installer_data.get('PRODUCTCODE', '')
    upgrade_code = installer_data.get('UPGRADECODE', '')
    arp_installer_type = installer_data.get('ARP_INSTALLER_TYPE', '')

    if product_code:
        installer["ProductCode"] = product_code

    if upgrade_code:
        entry = {"UpgradeCode": upgrade_code}
        if arp_installer_type:
            entry["InstallerType"] = arp_installer_type
        installer["AppsAndFeaturesEntries"] = [entry]
    elif product_code and arp_installer_type:
        installer["AppsAndFeaturesEntries"] = [{
            "ProductCode": product_code,
            "InstallerType": arp_installer_type
        }]

    if installer_data['INSTALLER_TYPE'] == "zip":
        installer["NestedInstallerType"] = installer_data['INSTALLER_NESTED_TYPE']
        installer["NestedInstallerFiles"] = db.get_Nested_Installer(installer_data['UID'])

        if installer_data['INSTALLER_NESTED_TYPE'] == "portable":
            installer["ArchiveBinariesDependOnPath"] = True
    return installer


def filter_entries_by_package_match_field(data: list[dict]):
    allowed = {"PackageName", "NormalizedPackageNameAndPublisher", "PackageIdentifier", "ProductCode", "PackageFamilyName"}
    if not isinstance(data, list):
        return []
    return [entry for entry in data
            if isinstance(entry, dict)
            and entry.get('PackageMatchField') in allowed
            and isinstance(entry.get('RequestMatch'), dict)]


def get_winget_Settings() -> dict:
    with SQLiteDatabase() as db:
        data = db.get_winget_Settings()
    return data


def authenticate_Client(token: str, ip: str, settings: dict, client_id: int = 0) -> bool:
    with SQLiteDatabase() as db:
        client_data = db.authenticate_client(token)
        if not client_data or client_data.get('ENABLED') != 1:
            return False

        dns_auth_enabled = settings.get('CLIENT_AUTHENTICATION_DNS_USAGE', "1") == "1"
        if dns_auth_enabled:
            dns_server = settings.get('DNS_SERVER', '192.168.1.1')
            hostname = get_hostname_from_ip_dns(ip, dns_server)
            if hostname.upper() != client_data.get('NAME', '').upper():
                return False

        now_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
        db.update_Client_Informations(ip, now_str, client_data['UID'], client_id)
        return True


def authorize_IP_Range(client_ip_str: str) -> bool:
    try:
        client_ip = ipaddress.ip_address(client_ip_str.strip())
    except ValueError:
        return False

    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()

    ip_ranges_raw = settings.get('IP_RESTRICTION', 'DEFAULT').upper()
    if ip_ranges_raw == "DEFAULT":
        return True

    ip_ranges = ip_ranges_raw.replace(';', ',').split(',')

    for entry in ip_ranges:
        entry = entry.strip()
        if not entry: continue

        try:
            if '-' in entry:
                start_str, end_str = [x.strip() for x in entry.split('-')]
                start_ip = ipaddress.ip_address(start_str)
                end_ip = ipaddress.ip_address(end_str)

                if client_ip.version == start_ip.version:
                    if start_ip <= client_ip <= end_ip:
                        return True
            else:
                network = ipaddress.ip_network(entry, strict=False)
                if client_ip in network:
                    return True
        except ValueError:
            continue
    return False


def write_log(client_ip: str, package_name: str, log_type: str):
    with SQLiteDatabase() as db:
        client = db.get_Client_by_IP(client_ip)
        package = db.get_specfic_Versions_from_Package(package_name.split(".")[0])

        if len(package) == 0:
            package = {"PACKAGE_ID": package_name, "VERSION": "Unknown"}

        if len(client) == 0:
            client = {"UID": "EXTERN", "NAME": client_ip}

        match log_type:
            case "INSTALLATION/UPDATE":
                text = json.dumps({"Client": client['NAME'], "Package": package['PACKAGE_ID'], "Version": package['VERSION']})
            case _:
                text = json.dumps({"Client": client['NAME'], "Package": "Unknown", "Version": ""})

        db.insert_Log(client['UID'], log_type, text, datetime.now().strftime("%d.%m.%Y %H:%M:%S"))
