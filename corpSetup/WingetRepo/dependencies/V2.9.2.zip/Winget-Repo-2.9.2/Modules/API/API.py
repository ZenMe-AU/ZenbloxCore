import secrets

from fastapi import APIRouter, Form, HTTPException, Depends, Request, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pathlib import Path
from typing import Optional
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import RedirectResponse
from uuid import uuid4

from Modules.API.Filter import LoginResponse, ClientVersionResponse, Package, package_version_form_data, Package_Version, AddStorePackageVersion
from Modules.API.api_extensions import api_limiter
from Modules.Database.Database import SQLiteDatabase
from Modules.Functions import parse_version, decode_flask_cookie, get_ip_from_hostname, get_serializer
from Modules.Login.Functions import check_Credentials
from Modules.Packages.Functions import get_package_service, add_package_service, edit_package_service, delete_package_service, delete_package_versions_service, add_package_version_service
from Modules.Store.Functions import download_file, check_for_new_Version, load_store_manifest, build_installer_overview, add_installer_version
from Modules.User.Functions import user_setup_finished, check_User_Exists
from Modules.Winget.Functions import authorize_IP_Range, authenticate_Client
from settings import PATH_LOGOS


client_api_bp = APIRouter()
oauth2_scheme = HTTPBearer(auto_error=False)


class APICheckerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if not user_setup_finished():
            return JSONResponse(status_code=503, content={"error": "Setup incomplete"})

        client_ip = request.client.host
        if not authorize_IP_Range(client_ip):
            return JSONResponse(status_code=403, content={"error": "IP address not authorized"})

        if request.url.path.lower() in ["/client/api/docs", "/client/api/redoc", "/client/api/openapi.json"]:
            flask_cookies = decode_flask_cookie(request.cookies.get('Winget-Repo'))
            status, _ = check_User_Exists('', user_id=flask_cookies.get('logged_in', ''))
            if not status:
                return RedirectResponse(url=f"{request.base_url.scheme}://{request.base_url.components.netloc}/", status_code=307)
        return await call_next(request)


async def verify_bearer_token(credentials: HTTPAuthorizationCredentials = Depends(oauth2_scheme)) -> str:
    if credentials:
        token = credentials.credentials
        with SQLiteDatabase() as db:
            session = db.get_Session_Token(token)
            if not session:
                raise HTTPException(status_code=401, detail="Invalid or expired token")
            db.update_Session_Timestamp(token)
            return token
    raise HTTPException(status_code=401, detail="Invalid or expired token")


# LOGIN
@client_api_bp.post("/login", tags=["Authentication"], summary="Authenticate user and generate a session token", response_model=LoginResponse)
@api_limiter.limit("5/minute")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    """
    Authenticates a user using a username and password.

    If the credentials are valid, a new session token is generated and returned.
    If the credentials are invalid, a **401 Unauthorized** error is returned.

    **Parameters:**
    - **username**: The user's login name
    - **password**: The user's password

    **Returns:**
    - JSON object containing the generated session token
    """
    with SQLiteDatabase() as db:
        exists, user_id = check_Credentials(username, password)
        if exists:
            token = db.create_Session_Token(user_id, secrets.token_urlsafe(32))
            return JSONResponse(content={"message": token}, status_code=200)
    raise HTTPException(status_code=401, detail="Unauthorized")


# LOGOUT
@client_api_bp.post("/logout", tags=["Authentication"], summary="Terminate an active user session")
async def logout(token: str = Form(...)):
    """
    Deletes the provided session token from the database.

    The logout request is always treated as successful,
    even if the provided token does not exist or is already invalid.

    **Parameters:**
    - **token**: The session token to invalidate

    **Returns:**
    - JSON confirmation message
    """
    with SQLiteDatabase() as db:
        exists = db.get_Session_Token(token)
        if exists:
            db.delete_Session_Token(token=token)
    return JSONResponse(content={"message": "Logout Successful!"}, status_code=200)


# NUR Bearer Token
@client_api_bp.get("/test", tags=["Authentication"], summary="Check API availability and authentication functionality")
async def test(token: str = Depends(verify_bearer_token)):
    """
    Performs a simple API functionality test.

    This endpoint is protected and requires a valid **Bearer token**.
    It is commonly used for health monitoring or verifying authentication flow.

    **Parameters:**
    - **token**: Bearer token from the Authorization header

    **Returns:**
    - Confirmation message indicating the API is operational
    """
    return {"Message": "Its working!"}


# Bearer oder Auth-Token
@client_api_bp.post("/client_version", tags=["Winget-Repo Client"], summary="Winget-Repo Client Version", response_model=ClientVersionResponse)
async def client_version(request: Request, auth_token: Optional[str] = Form(None), client: Optional[int] = Form(None), token_auth: Optional[HTTPAuthorizationCredentials] = Depends(oauth2_scheme)):
    """
    Returns the latest available version of the Winget-Repo Client.
    Checks Bearer Token first, then 'Auth-Token' in body.
    """
    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()
        if bool(int(settings.get("CLIENT_AUTHENTICATION", "0"))):
            if token_auth:
                session = db.get_Session_Token(token_auth.credentials)
                if not session:
                    raise HTTPException(status_code=401, detail="Invalid or expired token")
                db.update_Session_Timestamp(token_auth.credentials)
            else:
                client_value = client if client else 0
                client_ip = request.client.host
                if not authenticate_Client(auth_token, client_ip, settings, client_value):
                    raise HTTPException(status_code=401, detail="Invalid Auth-Token")
    return JSONResponse(content={"Version": "2.9.0.1"}, status_code=200)


# Bearer oder Auth-Token – Packages
@client_api_bp.post("/get_packages", tags=["Packages"], summary="Retrieve all available packages including versions and logos", response_model=list[Package])
async def get_packages(request: Request, include_disabled: bool=False, auth_token: Optional[str] = Form(None), client: Optional[int] = Form(None), token_auth: Optional[HTTPAuthorizationCredentials] = Depends(oauth2_scheme)):
    """
    Returns a complete list of all available packages including metadata,
    available versions, and Base64-encoded package logos.

    If client authentication is enabled, client-specific blacklist rules apply
    and certain packages may be filtered out based on the authentication token.

    **Parameters:**
    - **auth**: Authentication token (Bearer or Client Auth-Token)
    - **include_disabled**: If `True`, disabled packages will also be included

    **Returns:**
    - JSON list of package objects containing full metadata
    """
    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()
        if bool(int(settings.get("CLIENT_AUTHENTICATION", "0"))):
            if token_auth:
                session = db.get_Session_Token(token_auth.credentials)
                if not session:
                    raise HTTPException(status_code=401, detail="Invalid or expired token")
                db.update_Session_Timestamp(token_auth.credentials)
            else:
                client_value = client if client else 0
                client_ip = request.client.host
                if not authenticate_Client(auth_token, client_ip, settings, client_value):
                    raise HTTPException(status_code=401, detail="Invalid Auth-Token")

        serializer = get_serializer(request.app.state.DOWNLOAD_KEY)
        logo_base = f"{request.url.scheme}://{request.url.netloc}/api/logo"
        data = db.get_All_Packages(include_disabled)
        for d in data:
            versions = db.get_All_Versions_from_Package(d["PACKAGE_ID"], not include_disabled)
            version_dummy = sorted(((v["VERSION"], v["UID"]) for v in versions), key=lambda x: parse_version(x[0]), reverse=True)
            d["VERSIONS"] = [item[0] for item in version_dummy]
            d["VERSIONS_UID"] = [item[1] for item in version_dummy]

            logo_name = d.get("PACKAGE_LOGO", "dummy.png")
            logo_path = Path(PATH_LOGOS) / logo_name

            if logo_path.exists() and logo_name != "dummy.png":
                token = serializer.dumps(logo_name)
                d["PACKAGE_LOGO"] = f"{logo_base}/{token}"
            else:
                d["PACKAGE_LOGO"] = ""
        if auth_token:
            blacklist = db.get_Blacklist_for_client(auth_token)
            data = [d for d in data if d["PACKAGE_ID"] not in blacklist]
        return JSONResponse(content=data, status_code=200)


# Bearer
@client_api_bp.post("/add_package", tags=["Packages"], summary="Add a new package", response_model=list[Package])
async def add_package(package_id: str = Form(...), package_name: str = Form(...), package_publisher: str = Form(...), package_description: str = Form(...), Logo: Optional[UploadFile] = File(None), token: str = Depends(verify_bearer_token)):
    """
    Returns a complete list of all available packages including metadata,
    available versions, and Base64-encoded package logos.

    If client authentication is enabled, client-specific blacklist rules apply
    and certain packages may be filtered out based on the authentication token.

    **Parameters:**
    - **auth**: Authentication token (Bearer or Client Auth-Token)
    - **include_disabled**: If `True`, disabled packages will also be included

    **Returns:**
    - JSON list of package objects containing full metadata
    """
    data = {"package_id": package_id, "package_name": package_name, "package_publisher": package_publisher, "package_description": package_description}
    package = get_package_service(data.get("package_id", ''))
    if package:
        raise HTTPException(status_code=401, detail="Package ID already available!")

    if len(data) > 0:
        status, package_id = add_package_service(data, Logo)
        if status:
            return JSONResponse(content={"Message": "Package was added successfully!"}, status_code=200)
        else:
            raise HTTPException(status_code=401, detail="Package can't be created. Try again!")
    else:
        raise HTTPException(status_code=404, detail="Error. No Data found!")


# Bearer
@client_api_bp.patch("/edit_package/{package_id}", tags=["Packages"], summary="Edit an existing package", response_model=dict)
async def edit_package(package_id: str, package_name: str = Form(...), package_publisher: str = Form(...), package_description: str = Form(...), Logo: Optional[UploadFile] = File(None), reset_logo: bool = Form(False), token: str = Depends(verify_bearer_token)):
    """
    Edits the details of an existing package including name, publisher, description, and logo.

    **Parameters:**
    - **package_id**: ID of the package to edit
    - **package_name**: Updated name
    - **package_publisher**: Updated publisher
    - **package_description**: Updated description
    - **Logo**: Updated logo file
    - **reset_logo**: Set to `true` to reset the logo. Takes precedence over **Logo**.

    **Returns:**
    - JSON message confirming package update
    """
    data = {
        "package_name": package_name,
        "package_publisher": package_publisher,
        "package_description": package_description,
        "reset_logo": "1" if reset_logo else "0"
    }

    package = get_package_service(package_id)
    if not package:
        raise HTTPException(status_code=404, detail="Package not found!")

    status, _ = edit_package_service(package_id, data, Logo)
    if status:
        return JSONResponse(content={"Message": "Package was updated successfully!"}, status_code=200)
    else:
        raise HTTPException(status_code=400, detail="Changes could not be saved. Try again!")


# Bearer
@client_api_bp.delete("/delete_package/{package_id}", tags=["Packages"], summary="Delete an existing package", response_model=dict)
async def delete_package(package_id: str, token: str = Depends(verify_bearer_token)):
    """
    Deletes an existing package by its ID.

    **Parameters:**
    - **package_id**: ID of the package to delete

    **Returns:**
    - JSON message confirming package deletion
    """
    status = delete_package_service(package_id)
    if status:
        return JSONResponse(content={"Message": "Package was deleted successfully!"}, status_code=200)
    else:
        raise HTTPException(status_code=404, detail="Package not found!")


# Bearer
@client_api_bp.get("/get_package_versions/{package_id}", tags=["Package Versions"], summary="Retrieve all available versions from a package", response_model=list[Package_Version])
async def get_package_versions(package_id: str, token: str = Depends(verify_bearer_token)):
    """
    Returns a complete list of all available versions from a package.

    **Parameters:**
    - **package_id**: ID of the package

    **Returns:**
    - JSON list of package version objects containing full metadata
    """
    with SQLiteDatabase() as db:
        data = db.get_All_Versions_from_Package(package_id)
        if data:
            for d in data:
                d['NESTED_PACKAGE_INSTALLER_PATHS'] = db.get_Nested_Installer(d['UID'])
        return JSONResponse(content=data, status_code=200)


# Bearer
@client_api_bp.get("/get_specific_package_version/{version_uid}", tags=["Package Versions"], summary="Retrieve a specific version from a package", response_model=Package_Version)
async def get_specific_package_version(version_uid: str, token: str = Depends(verify_bearer_token)):
    """
    Returns a specific version from a package.

    **Parameters:**
    - **version_uid**: UID of the package version

    **Returns:**
    - JSON String of a package version objects containing full metadata
    """
    with SQLiteDatabase() as db:
        data = db.get_specfic_Versions_from_Package(version_uid)
        if data:
            data['NESTED_PACKAGE_INSTALLER_PATHS'] = db.get_Nested_Installer(data['UID'])
        return JSONResponse(content=data, status_code=200)


# Bearer
@client_api_bp.post("/add_package_version/{package_id}", tags=["Package Versions"], summary="Add a new package version", response_model=dict)
async def add_package_version(package_id: str, file: Optional[UploadFile] = File(None), token: str = Depends(verify_bearer_token), data: dict = Depends(package_version_form_data)):
    """
    Adds a new version to an existing package, including file upload and optional switches.

    **Parameters:**
    - **package_id**: ID of the package
    - **file**: File of the new version (either this or installer_url is required)
    - **data**: Metadata and switches for the new version. Can contain `installer_url` as alternative to file upload.

    **Returns:**
    - JSON message confirming version addition and the new version UID
    """
    installer_url = data.get("installer_url", "").strip()
    has_file = file and file.filename
    has_url = bool(installer_url)

    if not has_file and not has_url:
        raise HTTPException(status_code=400, detail="Either a file or an URL must be provided!")

    if not has_file and has_url:
        filename = installer_url.split("/")[-1].split("?")[0]
        try:
            file = download_file(installer_url, filename, return_filestorage=True)
            if not file:
                raise HTTPException(status_code=400, detail="Error downloading file from URL!")
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Download error: {str(e)}")

    if not data:
        raise HTTPException(status_code=400, detail="Data is missing!")

    try:
        status, message_or_uid = add_package_version_service(package_id, data, file)
    except Exception:
        raise HTTPException(status_code=500, detail="Error creating the package version.")

    if status:
        return JSONResponse(content={"Message": "Package version was added successfully!", "UID": message_or_uid}, status_code=201)
    else:
        if "already exists" in message_or_uid:
            raise HTTPException(status_code=409, detail=message_or_uid)
        elif "doesn't exist" in message_or_uid:
            raise HTTPException(status_code=404, detail=message_or_uid)
        else:
            raise HTTPException(status_code=400, detail=message_or_uid)


# Bearer
@client_api_bp.get("/get_store_package_updates/{package_id}", tags=["Package Versions"], summary="Get package version updates via the store", response_model=dict)
async def get_store_package_updates(package_id: str, token: str = Depends(verify_bearer_token)):
    """
    Checks the package store for available version updates of a package.
    If a new version is available, the response also contains the list of
    installers (with their index/ID) found in the store manifest for that
    new version, so the IDs can be passed directly to the "add version"
    endpoint.

    **Parameters:**
    - **package_id**: ID of the package

    **Returns:**
    - JSON object containing the available package update (current/available
      version + installer list), or an empty object if no update is available
    """
    package = get_package_service(package_id)
    if not package:
        raise HTTPException(status_code=404, detail="Package not found!")

    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()

    if settings['PACKAGE_STORE'] != "1":
        raise HTTPException(status_code=400, detail="Package Store is deactivated!")

    packages, update_status = check_for_new_Version([package])
    if not update_status:
        return JSONResponse(content={}, status_code=200)

    package = packages[0]
    current_version, available_version = package['NEW_VERSION'][1], package['NEW_VERSION'][2]

    p_infos, error = load_store_manifest(package_id, available_version)
    if error:
        raise HTTPException(status_code=404, detail=error)

    with SQLiteDatabase() as db:
        overview = build_installer_overview(db, package_id, available_version, p_infos)

    installers = [
        {
            "installer_id": entry["INDEX"],
            "architecture": entry.get('Architecture', 'x64'),
            "installer_type": entry.get('InstallerType', 'msi'),
            "scope": entry.get('Scope', p_infos.get('Scope', 'machine')),
            "already_exists": entry["EXISTS"]
        }
        for entry in overview
    ]

    content = {
        "package_id": package_id,
        "current_version": current_version,
        "available_version": available_version,
        "installers": installers
    }
    return JSONResponse(content=content, status_code=200)


# Bearer
@client_api_bp.post("/add_store_package/{package_id}", tags=["Package Versions"], summary="Add a new version to an existing package via the store",  response_model=list[Package_Version])
async def add_store_package(package_id: str, body: AddStorePackageVersion, token: str = Depends(verify_bearer_token)):
    """
    Adds one or more new versions to an already existing package via the package store.

    **Parameters:**
    - **package_id**: ID of the package
    - **body.VERSION**: Version to be installed from the store
    - **body.INSTALLER_IDS**: List of installer indices from the store manifest to be added

    **Returns:**
    - JSON object containing a status message and any errors per installer
    """
    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()
        if settings['PACKAGE_STORE'] != "1":
            raise HTTPException(status_code=400, detail="Package Store is deactivated!")

        if not db.check_Package_exists(package_id):
            raise HTTPException(status_code=404, detail="Package not found!")

        if not body.INSTALLER_IDS:
            raise HTTPException(status_code=400, detail="No installer ids given!")

        p_infos, error = load_store_manifest(package_id, body.VERSION)
        if error:
            raise HTTPException(status_code=404, detail=error)

        added = 0
        errors = []

        for i in body.INSTALLER_IDS:
            if i < 0 or i > (len(p_infos['Installers']) - 1):
                errors.append(f"Installer index {i} does not exist!")
                continue

            installer = p_infos['Installers'][i]
            success, message = add_installer_version(db, package_id, body.VERSION, installer)
            if success:
                added += 1
            else:
                errors.append(f"Installer index {i}: {message}")

    if added == 0:
        raise HTTPException(status_code=400, detail={"message": "No versions were added!", "errors": errors})

    return JSONResponse(content={"message": f"{added} version(s) added successfully!", "errors": errors}, status_code=200)


# Bearer
@client_api_bp.delete("/delete_package_version/{package_id}", tags=["Package Versions"], summary="Delete package versions", response_model=dict)
async def delete_package_version(package_id: str, versions_uids: list[str] = Form(...), token: str = Depends(verify_bearer_token)):
    """
    Deletes one or more versions of a package by their UIDs.

    **Parameters:**
    - **package_id**: ID of the package
    - **versions_uids**: List of version UIDs to delete

    **Returns:**
    - JSON message confirming deletion
    """
    package = get_package_service(package_id)
    if not package:
        raise HTTPException(status_code=404, detail="Package not found!")

    if not versions_uids:
        raise HTTPException(status_code=400, detail="No versions selected!")

    if len(versions_uids) == 1 and "," in versions_uids[0]:
        versions_uids = [v.strip() for v in versions_uids[0].split(",")]

    delete_package_versions_service(versions_uids)
    return JSONResponse(content={"Message": "Package versions deleted successfully!"}, status_code=200)


# Bearer
@client_api_bp.get("/get_clients", tags=["Clients"], summary="Retrieve all clients", response_model=list)
async def get_clients(token: str = Depends(verify_bearer_token)):
    """
    Returns a complete list of all registered clients.

    **Returns:**
    - JSON list of client objects containing full metadata
    """
    with SQLiteDatabase() as db:
        clients = db.get_All_Clients()

    return JSONResponse(content=clients, status_code=200)


# Bearer
@client_api_bp.post("/add_client", tags=["Clients"], summary="Add a new client and return its auth token", response_model=dict)
async def add_client(request: Request, client_name: str = Form(...), token: str = Depends(verify_bearer_token)):
    """
    Adds a new client by hostname, resolves its IP via DNS (if enabled) and generates an auth token.

    **Parameters:**
    - **client_name**: The hostname of the client to add

    **Returns:**
    - JSON object containing the client ID and the generated auth token
    """
    if not client_name:
        raise HTTPException(status_code=400, detail="No client name provided!")

    with SQLiteDatabase() as db:
        settings = db.get_winget_Settings()

    if settings.get('CLIENT_AUTHENTICATION_DNS_USAGE', "1") == "1":
        ip = get_ip_from_hostname(client_name, settings.get('DNS_SUFFIX', ''), settings.get('DNS_SERVER', '192.168.1.1'))
    else:
        ip = "127.0.0.1"

    if not ip:
        raise HTTPException(status_code=400, detail="Could not resolve IP from hostname. Check the input or DNS config!")

    c_id = str(uuid4())
    auth_token = str(uuid4())

    with SQLiteDatabase() as db:
        status = db.add_New_Client(c_id, client_name.upper()[:25], ip, auth_token)

    if status:
        return JSONResponse(content={"Message": "Client was added successfully!", "client_id": c_id, "auth_token": auth_token}, status_code=201)
    else:
        raise HTTPException(status_code=409, detail="Hostname already exists!")


# Bearer
@client_api_bp.delete("/delete_client/{client_id}/{auth_token}", tags=["Clients"], summary="Delete an existing client", response_model=dict)
async def delete_client(client_id: str, auth_token: str, token: str = Depends(verify_bearer_token)):
    """
    Deletes an existing client by its ID and auth token.

    **Parameters:**
    - **client_id**: The unique ID of the client to delete
    - **auth_token**: The auth token of the client to delete

    **Returns:**
    - JSON message confirming client deletion
    """
    if not client_id or not auth_token:
        raise HTTPException(status_code=400, detail="No data provided!")

    with SQLiteDatabase() as db:
        client = db.get_Client_by_ID(client_id)
        if not client:
            raise HTTPException(status_code=404, detail="Client not found!")

        db.delete_Client(client_id, auth_token)

    return JSONResponse(content={"Message": "Client was removed successfully!"}, status_code=200)
